"""
Helper functions for CHANNELS_DATABASE.
H11A-quadruples, April 2020.
"""

from database.database import CHANNELS_DATABASE
from database.helpers_auth import find_u_id, is_user_slackr_owner

def reset_channels_data():
    """
    Clears the CHANNELS_DATABASE by resetting all created channels.
    """
    empty_data = {"channels": []}
    CHANNELS_DATABASE.update(empty_data)


def is_user_in_channel(token, channel_id):
    """
    Check if a given user is a member of a given channel.

    Args:
        token (str): Token of the user being checked.
        channel_id (int): id of the channel being checked.
    Returns:
        True if the user is in the channel, False if the user is not in the channel.
    """
    u_id = find_u_id(token)
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if channel["channel_id"] == channel_id:
            for member in channel["all_members"]:
                if member["u_id"] == u_id:
                    return True
            break
    return False


def get_channel_id():
    """
    Generates a channel_id by adding 1 to the existing number of channels.
    The first channel will have an id of 1.

    Returns:
        Newly generated channel_id (int).
    """
    channels_data = CHANNELS_DATABASE.get()
    num_channels = len(channels_data["channels"])
    return num_channels + 1


def is_user_owner(token, channel_id):
    """
    Check if a given user is an owner of the Slackr or an owner of a given channel.

    Args:
        token (str): Token of the user being checked.
        channel_id (str): id of the channel of which the user may be an owner.
    Returns:
        True if the user is a Slackr owner or an owner of the channel and False otherwise.
    """
    ## Check if the user is the owner of the Slackr (first person who registered)
    u_id = find_u_id(token)
    if is_user_slackr_owner(u_id):
        return True

    ## If not a Slackr owner, check that the user is an owner of the channel
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if channel["channel_id"] == channel_id:
            for owner in channel["owner_members"]:
                if owner["u_id"] == u_id:
                    return True
            break
    return False


def does_channel_exist(channel_id):
    """
    Check if a given channel_id exists.

    Args:
        channel_id (int): id of channel to check existence of.
    Returns:
        True if the channel exists, False if the channel does not exist.
    """
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if channel["channel_id"] == channel_id:
            return True
    return False


def is_standup_active(channel_id):
    """
    Check if a standup is currently active in a given channel.

    Args:
        channel_id (int): id of channel to check if a standup is active in.
    Returns:
        True if a standup is active in the channel, False if a standup is not active,
        None if channel does not exist.
    """
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if channel["channel_id"] == channel_id:
            return channel["is_standup_active"]
    return None


def reset_hangman_data(channel_id):
    """
    Resets the hangman data for a given channel to the default values.

    Args:
        channel_id (int): id of the channel to reset hangman data in.
    """
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if channel["channel_id"] == channel_id:
            channel["hangman_word"] = None
            channel["hangman_guessed"] = []
            channel["hangman_level"] = 0
            break
    CHANNELS_DATABASE.update(channels_data)
