"""
Helper functions for AUTH_DATABASE.
H11A-quadruples, April 2020.
"""

import hashlib
import re
from datetime import datetime, timezone
import random
import string
import jwt
from database.database import AUTH_DATABASE

def reset_auth_data():
    """
    Clears the AUTH_DATABASE by resetting all registered users, active tokens
    and deleted users.
    """
    empty_data = {
        "registered_users": [],
        "active_tokens": [],
        "deleted_users": []
    }
    AUTH_DATABASE.update(empty_data)


def check_email(email):
    """
    Check if an email is formatted correctly.

    Args:
        email (str): Email to check.
    Returns:
        True if email is formatted correctly, False if email is formatted incorrectly.
    """
    regex = r"^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$"
    if re.search(regex, email):
        return True
    return False


def search_email(email):
    """
    Check if an email is registered and in the database.

    Args:
        email (str): Email to search for.
    Returns:
        True if the email if registered, False if the email is not registered.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["email"] == email:
            return True
    return False


def get_hash(password):
    """
    Hash a given password.

    Args:
        password (str): Password to hash.
    Returns:
        The hashed password (str).
    """
    return hashlib.sha256(password.encode()).hexdigest()


def check_password(email, password):
    """
    Check if a user enters the correct password.

    Args:
        email (str): Email of the user logging in.
        password (str): Password with which the user is attempting to log in with.
    Returns:
        True if the password is correct, False if the password is incorrect.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["email"] == email:
            if user["password_hash"] == get_hash(password):
                return True
            break
    return False


def generate_token(u_id):
    """
    Generates a valid token by adding it to the list of "active_tokens" in the database.

    Args:
        u_id (int): id of the user to generate a token for.
    Returns:
        A JSON Web Token (str) with a timestamp payload.
    """
    ## Generate a secret based on the current time
    now = datetime.now()
    secret = str(now.replace(tzinfo=timezone.utc).timestamp())

    ## Generate a jwt
    ##
    ## This signature will be very difficult to replicate due to the secret
    ## being the time of register/login
    payload = {"u_id": u_id}
    encoded_jwt = jwt.encode(payload, secret, algorithm="HS256").decode("utf-8")

    ## Add the token to the list of "active_tokens" in the database
    auth_data = AUTH_DATABASE.get()
    auth_data["active_tokens"].append({
        "u_id": u_id,
        "token": encoded_jwt
    })
    AUTH_DATABASE.update(auth_data)
    return encoded_jwt


def is_token_valid(token):
    """
    Check if a token is active and valid.

    Args:
        token (str): Token to check.
    Returns:
        True if token is active, False if token is not active.
    """
    auth_data = AUTH_DATABASE.get()
    for valid_token in auth_data["active_tokens"]:
        if valid_token["token"] == token:
            return True
    return False


def get_u_id():
    """
    Generates a user_id by adding 1 to the number of registered and unregistered
    users. The first user to register will have u_id 1.

    Returns:
        Newly generated user_id (int).
    """
    auth_data = AUTH_DATABASE.get()
    num_users = len(auth_data["registered_users"]) + len(auth_data["deleted_users"])
    return num_users + 1


def is_handle_in_use(handle):
    """
    Check if a given handle is already in use.

    Args:
        handle (str): Handle to check.
    Returns:
        True if handle is in use, False if handle is not in use.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["handle_str"] == handle:
            return True
    return False


def get_handle(name_first, name_last):
    """
    Generate a handle that is the concatenation of a lowercase-only first name
    and last name. If the concatenation is longer than 20 characters, it is
    cutoff at 20 characters. If the handle is already taken, it is made unique.

    Args:
        name_first (str): First name of user.
        name_last (str): Last name of user.
    Returns:
        Uniquely generated handle (str).
    """
    handle = (name_first + name_last).lower()
    if len(handle) > 20:
        handle = handle[:20] ## 0 to 19 --> 20 characters

    ## Make the handle unique
    original_len = len(handle)
    num = 1
    while is_handle_in_use(handle):
        handle = handle[:original_len] + str(num)
        num += 1
    return handle


def find_u_id(token):
    """
    Find the corresponding u_id for a given token.

    Args:
        token (str): Token to find corresponding u_id for.
    Returns:
        u_id (int) corresponding to given token.
    """
    auth_data = AUTH_DATABASE.get()
    for valid_token in auth_data["active_tokens"]:
        if valid_token["token"] == token:
            return valid_token["u_id"]
    return None ## if token doesn't exist


def is_user_slackr_owner(u_id):
    """
    Check if a given user is a Slackr owner.

    Args:
        u_id (int): id of user to check.
    Returns:
        True if user is a Slackr owner, False if user is not a Slackr owner.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["u_id"] == u_id:
            ## User found, check their permissions
            if user["global_permission_id"] == 1:
                return True
            break
    return False


def does_user_exist(u_id):
    """
    Check if a user exists (is registered).

    Args:
        u_id (int): id of user to search for.
    Returns:
        True if user is registered, False if user is not registered.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["u_id"] == u_id:
            return True
    return False


def generate_code():
    """
    Generate a string of 10 random characters for reset codes and image codes.

    Returns:
        A randomly generated string of length 10.
    """
    return "".join([random.choice(string.ascii_letters) for _ in range(10)])


def is_reset_code_valid(reset_code):
    """
    Check if a given reset code is valid.

    Args:
        reset_code (str): Code to check.
    Returns:
        True if reset code is valid, False if reset code is invalid.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["reset_code"] == reset_code:
            return True
    return False


def is_user_removed(u_id):
    """
    Check if a user has been removed from the Slackr by an owner.

    Args:
        u_id (int): id of user to check.
    Returns:
        True if the user is removed, False if the user is not removed.
    """
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["deleted_users"]:
        if user["u_id"] == u_id:
            return True
    return False
