"""
Documents the structure of the AUTH, CHANNELS, MESSAGES databases.
H11A-quadruples, April 2020.
"""

import pickle

#####################################################################

AUTH_DB_DICT = {
    "registered_users": [
        # {
        #     "u_id": #,
        #     "email": #,
        #     "name_first": #,
        #     "name_last": #,
        #     "handle_str": #,
        #     "password_hash": #,
        #     "global_permission_id": #,
        #     "reset_code": #,
        #     "profile_img_url": #
        # },
    ],
    "active_tokens": [
        # {
        #     "u_id": #,
        #     "token": #
        # },
    ],
    "deleted_users": [
        # {
        #     "u_id": #,
        #     "email": #
        # }
    ]
}

CHANNELS_DB_DICT = {
    "channels": [
        # {
        #     "channel_id": #,
        #     "name": #,
        #     "owner_members": [
        #         {
        #             "u_id": #,
        #             "name_first": #,
        #             "name_last": #,
        #             "profile_img_url": #
        #         },
        #     ],
        #     "all_members": [
        #         {
        #             "u_id": #,
        #             "name_first": #,
        #             "name_last": #,
        #             "profile_img_url": #
        #         },
        #     ],
        #     "is_public": #,
        #     "is_standup_active": #,
        #     "standup_time_finish": #,
        #     "standup_queue": [],
        #     "hangman_word": #,
        #     "hangman_guessed": [],
        #     "hangman_level": #
        # },
    ]
}

MESSAGES_DB_DICT = {
    "messages": [
        # {
        #     "channel_id": #,
        #     "message_id": #,
        #     "u_id": #,
        #     "message": #,
        #     "time_created": #,
        #     "reacts:" [
        #         {
        #             "react_id": #,
        #             "u_ids": [],
        #             "is_this_user_reacted": #
        #         },
        #     ],
        #     "is_pinned": #
        # },
    ],
    "queued_message_ids": [],
    "removed_messages": [
        # {
        #     "channel_id": #,
        #     "message_id": #,
        #     "u_id": #,
        #     "message": #,
        #     "time_created": #,
        # }
    ]
}

#####################################################################

class Database:
    """
    Encapsulates a database in the form of a dictionary.
    """
    def __init__(self, dbase):
        """
        Construct a new 'Database' object.

        Args:
            dbase (dict): Dictionary containing some data.
        """
        self.database = dbase

    def get(self):
        """
        Get the database.

        Returns:
            Dictionary contained in the 'Database' object.
        """
        return self.database

    def update(self, new_database):
        """
        Update the database with a new database.

        Args:
            new_database (dict): Dictionary containing updated data.
        """
        self.database = new_database

AUTH_DATABASE = Database(AUTH_DB_DICT)
CHANNELS_DATABASE = Database(CHANNELS_DB_DICT)
MESSAGES_DATABASE = Database(MESSAGES_DB_DICT)

#####################################################################

def update_database(file, data):
    """
    Dumps some given data into a given file.

    Args:
        file (str): Name of the file in which to dump data.
        data (dict): Dictionary containing the data to dump.
    """
    pickle.dump(data, open(file, "wb"))

def get_database(file):
    """
    Unpickles a given file and returns its contents.

    Args:
        file (str): Name of the file from which to load data.
    Returns:
        Dictionary containing unpickled data.
    """
    return pickle.load(open(file, "rb"))
