"""
Helper functions for MESSAGES_DATABASE.
H11A-quadruples, April 2020.
"""

from datetime import datetime, timezone
from database.database import MESSAGES_DATABASE
from database.helpers_auth import find_u_id, is_user_removed
from database.helpers_channels import is_user_in_channel

def reset_messages_data():
    """
    Clears the MESSAGES_DATABASE by resetting all sent messages, queued messages
    and removed messages.
    """
    empty_data = {
        "messages": [],
        "queued_message_ids": [],
        "removed_messages": []
    }
    MESSAGES_DATABASE.update(empty_data)


def get_message_id():
    """
    Generates a message_id by adding 1 to the existing number of messages.
    The first message will have an id of 1.

    Returns:
        Newly generated message_id (int).
    """
    messages_data = MESSAGES_DATABASE.get()
    num_msgs = len(messages_data["messages"])
    num_msgs += len(messages_data["queued_message_ids"])
    num_msgs += len(messages_data["removed_messages"])
    return num_msgs + 1


def do_sendlater(u_id, channel_id, message, m_id):
    """
    Send a message and remove its message_id from the queued_message_ids.

    Args:
        u_id (int): id of the user sending the message.
        channel_id (int): id of the channel in which to send the message.
        message (str): Message to send in the channel.
        m_id (int): id of the message being sent.
    Returns:
        Nothing if the given user has been removed before the message was scheduled to be sent.
    """
    if is_user_removed(u_id):
        ## Don't remove queued message_id since it isn't being moved
        ## to the messages database.
        return

    ## Find the timestamp of the message
    now = datetime.utcnow()
    timestamp = int(now.replace(tzinfo=timezone.utc).timestamp())

    ## Add the message to the database
    messages_data = MESSAGES_DATABASE.get()
    messages_data["messages"].append({
        "channel_id": channel_id,
        "message_id": m_id,
        "u_id": u_id,
        "message": message,
        "time_created": timestamp,
        "reacts": [], ## no reacts by default
        "is_pinned": False ## not pinned by default
    })

    ## Removed queued id
    messages_data["queued_message_ids"].remove(m_id)
    MESSAGES_DATABASE.update(messages_data)


def does_message_exist(message_id):
    """
    Check if a given message_id exists.

    Args:
        message_id (int): id of the message to check.
    Returns:
        True if the message exists, False if the message does not exist.
    """
    messages_data = MESSAGES_DATABASE.get()
    for message in messages_data["messages"]:
        if message["message_id"] == message_id:
            return True
    return False


def can_user_react(token, message_id):
    """
    Check if a user can react to a given message.

    Args:
        token (str): Token of the user attempting to react to a message.
        message_id (int): id of the message being reacted to.
    Returns:
        True if the message exists and the user is in the channel that the message was sent,
        False otherwise.
    """
    if does_message_exist(message_id):
        messages_data = MESSAGES_DATABASE.get()
        for message in messages_data["messages"]:
            if message["message_id"] == message_id:
                if is_user_in_channel(token, message["channel_id"]):
                    return True
                break
    return False


def has_user_reacted(token, message_id, react_id):
    """
    Check if a given user has already reacted to a given message with a given react_id.

    Args:
        token (str): Token of the user being checked.
        message_id (int): id of the message being checked.
        react_id (int): id of the react being checked.
    Returns:
        True if the given user has reacted to the given message with react_id,
        False otherwise.
    """
    u_id = find_u_id(token)
    messages_data = MESSAGES_DATABASE.get()
    for message in messages_data["messages"]:
        if message["message_id"] == message_id:
            for react in message["reacts"]:
                if react["react_id"] == react_id:
                    if u_id in react["u_ids"]:
                        return True
            break
    return False


def does_react_exist(react_id, reacts):
    """
    Check if a given react_id exists in a given list of reacts.

    Args:
        react_id (int): id of the react to search for.
        reacts (list): list of react dictionaries.
    Returns:
        True if react_id exists within the list of react dictionaries, False otherwise.
    """
    for react in reacts:
        if react["react_id"] == react_id:
            return True
    return False


def add_react(token, react_id, reacts):
    """
    Given a list of reacts, adds a user's u_id to the list of u_ids if the
    react already exists, otherwise create a new react in the list of reacts.

    Args:
        token (str): Token of user reacting.
        react_id (int): id of react with which the user reacted.
        reacts (list): list of react dictionaries to add to.
    Returns:
        Updated reacts (list) containing the user's new react.
    """
    u_id = find_u_id(token)
    if does_react_exist(react_id, reacts):
        ## If react_id already exists, add to list of u_ids
        for react in reacts:
            if react["react_id"] == react_id:
                react["u_ids"].append(u_id)
                react["is_this_user_reacted"] = True
    else:
        ## Else, create a new react dictionary
        reacts.append({
            "react_id": react_id,
            "u_ids": [u_id],
            "is_this_user_reacted": True ## by default
        })
    return reacts


def remove_react(token, react_id, reacts):
    """
    Given a list of reacts, removes the user's u_id from the list of u_ids if
    they aren't the only one in the list. If they are the only one in the list,
    removes the whole react dictionary.

    Args:
        token (str): Token of user unreacting.
        react_id (int): id of react with which the user is unreacting.
        reacts (list): list of react dictionaries to remove from.
    Returns:
        Updated reacts (list) no longer containing the user's react.
    """
    u_id = find_u_id(token)
    for react in reacts:
        if react["react_id"] == react_id:
            if len(react["u_ids"]) == 1 and u_id in react["u_ids"]:
                ## Remove the whole react dict from list
                reacts.remove(react)
            elif len(react["u_ids"]) > 1 and u_id in react["u_ids"]:
                ## Remove the u_id from the list of u_ids
                react["u_ids"].remove(u_id)
                react["is_this_user_reacted"] = False
            break
    return reacts


def is_pinned_already(message_id):
    """
    Check if a message is pinned.

    Args:
        message_id (int): id of message to check.
    Returns:
        True if the message is pinned, False if the message is not pinned.
    """
    messages_data = MESSAGES_DATABASE.get()
    for message in messages_data["messages"]:
        if message["message_id"] == message_id:
            return message["is_pinned"]
    return None


def did_user_send_message(token, message_id):
    """
    Check if a given user was the one to send a given message.

    Args:
        token (str): Token of user to check.
        message_id (int): id of message being checked.
    Returns:
        True if the given user sent the given message, False if user did not send given message.
    """
    u_id = find_u_id(token)
    messages_data = MESSAGES_DATABASE.get()
    for message in messages_data["messages"]:
        if message["message_id"] == message_id:
            if message["u_id"] == u_id:
                return True
            break
    return False
