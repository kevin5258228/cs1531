"""
Send an email to a given user's email containing their password reset code.
H11A-quadruples, April 2020.
"""

import smtplib
from constants import GMAIL_PORT, GMAIL_USER, GMAIL_PASS

def send_email(email, reset_code):
    """
    Sends an email to the user with their reset code.

    Args:
        email (str): Email to send the reset code to.
        reset_code (str): Code to be contained in the email.
    """
    session = smtplib.SMTP("smtp.gmail.com", GMAIL_PORT)
    session.ehlo()
    session.starttls()
    session.ehlo()
    session.login(GMAIL_USER, GMAIL_PASS)

    subject = "Reset code for Slackr password"
    body = f"Reset code: {reset_code}"
    message = f"Subject: {subject}\n\n{body}"

    session.sendmail(GMAIL_USER, email, message)
    session.quit()
