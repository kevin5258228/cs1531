"""
Some sample user and channel data to be used for testing.
H11A-quadruples, April 2020.
"""

from funcs.auth import auth_register
from funcs.channels import channels_create


#------------------------#
#         USERS          #
#------------------------#

def user1():
    """
    Registers a user Bob Ross.

    Returns:
        u_id (int) and token (str) for Bob Ross.
    """
    ## Assume auth_register() works
    user = auth_register("bob.ross@unsw.edu.au", "pword123", "Bob", "Ross")
    return (user["u_id"], user["token"])


def user2():
    """
    Registers a user Elon Musk.

    Returns:
        u_id (int) and token (str) for Elon Musk.
    """
    user = auth_register("elon.musk@unsw.edu.au", "pword456", "Elon", "Musk")
    return (user["u_id"], user["token"])


def user3():
    """
    Registers a user Steve Jobs.

    Returns:
        u_id (int) and token (str) for Steve Jobs.
    """
    user = auth_register("steve.jobs@unsw.edu.au", "pword789", "Steve", "Jobs")
    return (user["u_id"], user["token"])


#------------------------#
#        CHANNELS        #
#------------------------#

def chan1(token):
    """
    Create a public channel "channel1" and return its id.

    Args:
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    ## Assume channels_create() works
    channel = channels_create(token, "channel1", True)
    return channel["channel_id"]


def chan2(token):
    """
    Create a public channel "channel2" and return its id.

    Args:
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    channel = channels_create(token, "channel2", True)
    return channel["channel_id"]


def chan3(token):
    """
    Create a public channel "channel3" and return its id.

    Args:
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    channel = channels_create(token, "channel3", True)
    return channel["channel_id"]
