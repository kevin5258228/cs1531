"""
Functions to POST requests for sample data.
H11A-quadruples, April 2020.
"""

import requests
from constants import LOCALHOST_URL


#------------------------#
#         USERS          #
#------------------------#

def user1(port):
    """
    Registers a user Bob Ross by sending a POST request to the server.

    Args:
        port (int): Port number that the server is running on.
    Returns:
        u_id (int) and token (str) for Bob Ross.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/auth/register", json={
        "email": "bob.ross@unsw.edu.au",
        "password": "pword123",
        "name_first": "Bob",
        "name_last": "Ross"
    }).json()
    return (response["u_id"], response["token"])


def user2(port):
    """
    Registers a user Elon Musk by sending a POST request to the server.

    Args:
        port (int): Port number that the server is running on.
    Returns:
        u_id (int) and token (str) for Elon Musk.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/auth/register", json={
        "email": "elon.musk@unsw.edu.au",
        "password": "pword456",
        "name_first": "Elon",
        "name_last": "Musk"
    }).json()
    return (response["u_id"], response["token"])


def user3(port):
    """
    Registers a user Steve Jobs by sending a POST request to the server.

    Args:
        port (int): Port number that the server is running on.
    Returns:
        u_id (int) and token (str) for Steve Jobs.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/auth/register", json={
        "email": "steve.jobs@unsw.edu.au",
        "password": "pword789",
        "name_first": "Steve",
        "name_last": "Jobs"
    }).json()
    return (response["u_id"], response["token"])


#------------------------#
#        CHANNELS        #
#------------------------#

def chan1(port, token):
    """
    Create a public channel "channel1" and return its id.

    Args:
        port (int): Port number that the server is running on.
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/channels/create", json={
        "token": token,
        "name": "channel1",
        "is_public": True
    }).json()
    return response["channel_id"]


def chan2(port, token):
    """
    Create a public channel "channel2" and return its id.

    Args:
        port (int): Port number that the server is running on.
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/channels/create", json={
        "token": token,
        "name": "channel2",
        "is_public": True
    }).json()
    return response["channel_id"]


def chan3(port, token):
    """
    Create a public channel "channel3" and return its id.

    Args:
        port (int): Port number that the server is running on.
        token (str): Token of user creating the channel.
    Returns:
        channel_id (int) of newly created channel.
    """
    response = requests.post(f"{LOCALHOST_URL}:{port}/channels/create", json={
        "token": token,
        "name": "channel3",
        "is_public": True
    }).json()
    return response["channel_id"]


#------------------------#
#     CHANNEL FUNCS      #
#------------------------#

def join_req(port, token, channel_id):
    """
    User with given token joins channel with channel_id.

    Args:
        port (int): Port number that the server is running on.
        token (str): Token of user who is joining the channel.
        channel_id (int): id of the channel that the user is joining.
    """
    requests.post(f"{LOCALHOST_URL}:{port}/channel/join", json={
        "token": token,
        "channel_id": channel_id,
    })
