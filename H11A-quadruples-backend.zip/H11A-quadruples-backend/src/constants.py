"""
Configuration constants for Slackr.
H11A-quadruples, April 2020.
"""

## Path to AUTH, CHANNELS, MESSAGES pickled databases (relative to src/)
AUTH_DB_PATH = "db_auth.p"
CHANNELS_DB_PATH = "db_channels.p"
MESSAGES_DB_PATH = "db_messages.p"

## Number of seconds to wait before pickling current database states
SAVE_INTERVAL = 30

## Path to the folder in which cropped profile pictures are saved (relative to src/)
PFP_FOLDER = "profile_pics"

## localhost
LOCALHOST_URL = "http://127.0.0.1"

## Path to file from which to get word list (relative to /)
WORD_FILE = "/usr/share/dict/british-english"

## List of valid react_id's from Slackr frontend
VALID_REACT_IDS = [1]

## List of valid permission_id's (1 for owner, 2 for member)
VALID_PERMISSION_IDS = [1, 2]

## u_id of a deleted user
DELETED_USER_ID = -1

## Link to default profile picture
DEFAULT_PFP = "https://carleton.ca/law/wp-content/uploads/default-profile.jpg"

## Port number for gmail
GMAIL_PORT = 587

## gmail account for emailing reset codes
GMAIL_USER = "quadtruplereset@gmail.com"
GMAIL_PASS = "sweethomeAlabama"
