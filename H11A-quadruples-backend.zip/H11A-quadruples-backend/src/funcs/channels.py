"""
Implementations of the channels functions.
H11A-quadruples, April 2020.
"""

from error import AccessError, InputError
from database.database import AUTH_DATABASE, CHANNELS_DATABASE
from database.helpers_auth import is_token_valid, find_u_id
from database.helpers_channels import is_user_in_channel, get_channel_id

def channels_list(token):
    """
    Returns a list of channels that the user has joined.

    Args:
        token (str): Token for the user whose channels list is being requested.
    Raises:
        AccessError: if token is invalid.
    Returns:
        A list of channel dictionaries.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Loop through the channels in the database and append them to an empty
    ## list if the user with the given token is a member of that channel
    ch_list = {"channels": []}
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        if is_user_in_channel(token, channel["channel_id"]):
            ch_list["channels"].append({
                "channel_id": channel["channel_id"],
                "name": channel["name"]
            })
    return ch_list


def channels_listall(token):
    """
    Returns a list of all channels and their details.

    Args:
        token (str): Token of the user making the request.
    Raises:
        AccessError: if token is invalid.
    Returns:
        A list of channel dictionaries.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Loop through the channels in the database and append them to an empty list
    ch_list = {"channels": []}
    channels_data = CHANNELS_DATABASE.get()
    for channel in channels_data["channels"]:
        ch_list["channels"].append({
            "channel_id": channel["channel_id"],
            "name": channel["name"]
        })
    return ch_list


def channels_create(token, name, is_public):
    """
    Creates a new public or private channel with a given name.

    Args:
        token (str): Token of the user creating the channel.
        name (str): Name of the channel being created.
        is_public (bool): True if channel is a public channel, False if it is private.
    Raises:
        AccessError: if token is invalid.
        InputError: if channel name is more than 20 characters long.
    Returns:
        Dictionary containing the newly created channel's channel_id.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if len(name) > 20:
        raise InputError(description="Name is more than 20 characters long")

    ## Get info regarding the user who is creating the channel
    user_id = find_u_id(token)
    auth_data = AUTH_DATABASE.get()
    for user in auth_data["registered_users"]:
        if user["u_id"] == user_id:
            name_first = user["name_first"]
            name_last = user["name_last"]
            profile_img_url = user["profile_img_url"]
            break

    ## Generate a channel_id
    channel_id = get_channel_id()

    ## Add the channel to the database
    channels_data = CHANNELS_DATABASE.get()
    channels_data["channels"].append({
        "channel_id": channel_id,
        "name": name,
        "owner_members": [ ## person creating the channel is the owner by default
            {
                "u_id": user_id,
                "name_first": name_first,
                "name_last": name_last,
                "profile_img_url": profile_img_url
            }
        ],
        "all_members": [
            {
                "u_id": user_id,
                "name_first": name_first,
                "name_last": name_last,
                "profile_img_url": profile_img_url
            }
        ],
        "is_public": is_public,
        "is_standup_active": False, ## standup info blank
        "standup_time_finish": None,
        "standup_queue": [],
        "hangman_word": None, ## no hangman word initially
        "hangman_guessed": [], ## list of guessed letters
        "hangman_level": 0 ## start at level 0
    })
    CHANNELS_DATABASE.update(channels_data)
    return {"channel_id": channel_id}
