"""
Implementations of the channel functions.
H11A-quadruples, April 2020.
"""

from funcs.channels import channels_list
from funcs.user import user_profile
from error import AccessError, InputError
from database.database import CHANNELS_DATABASE, MESSAGES_DATABASE
from database.helpers_auth import (
    is_token_valid,
    does_user_exist,
    find_u_id,
    is_user_slackr_owner
)
from database.helpers_channels import (
    does_channel_exist,
    is_user_in_channel,
    is_user_owner
)

def channel_invite(token, channel_id, u_id):
    """
    Invites a user to join a channel with channel_id.

    Args:
        token (str): Token of the user who is inviting.
        channel_id (int): id of the channel that the user is being invited to.
        u_id (int): id of the user being invited.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a member of the given channel.
        InputError: if u_id does not refer to a valid user.
        InputError: if the user is already a member of the channel.
    Returns:
        Empty dictionary.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")
    result = channels_list(token)
    list_channels = result["channels"]
    if not any(ch["channel_id"] == channel_id for ch in list_channels):
        raise AccessError(description="Cannot invite users if you are not a member of the channel")

    ## Check for InputErrors
    if not does_user_exist(u_id):
        raise InputError(description="The person you are inviting does not exist")

    user_data = user_profile(token, u_id)
    first_name = user_data["user"]["name_first"]
    last_name = user_data["user"]["name_last"]
    profile_img_url = user_data["user"]["profile_img_url"]
    user_dict = {
        "u_id": u_id,
        "name_first": first_name,
        "name_last": last_name,
        "profile_img_url": profile_img_url
    }

    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            list_all_members = channel["all_members"]
            list_owner_members = channel["owner_members"]
            ## Check for InputErrors (..continued)
            if any(member["u_id"] == u_id for member in list_all_members):
                raise InputError(description="User is already a member of the channel")
            ## Assume that if a user is a Slackr owner (global_permission_id 1), then
            ## they get owner privileges in the channel that they join.
            if is_user_slackr_owner(u_id):
                list_owner_members.append(user_dict)
            list_all_members.append(user_dict)
            break
    CHANNELS_DATABASE.update(channels_data)
    return {}


def channel_details(token, channel_id):
    """
    Provide basic details for a channel that a given user is in.

    Args:
        token (str): Token of the user making the request.
        channel_id (int): id of the channel whose information is being requested.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a member of the channel.
        InputError: if the given channel_id is invalid.
    Returns:
        A dictionary containing the channel's name, owner_members and all_members.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="channel_id is not a valid channel")

    ## Check for AccessErrors (..continued)
    if not is_user_in_channel(token, channel_id):
        raise AccessError(description="Cannot view channel details if you are not a member")

    result = {}
    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            result["name"] = channel["name"]
            result["owner_members"] = channel["owner_members"]
            result["all_members"] = channel["all_members"]
    return result


def channel_messages(token, channel_id, start):
    """
    Return up to 50 messages in a given channel.

    Args:
        token (str): Token of the user making the request.
        channel_id (int): id of the channel to get messages from.
        start (int): index of the message to start from.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a member of the given channel.
        InputError: if channel_id is not a valid channel.
        InputError: if start is greater than or equal to the total number of channel messages.
    Returns:
        A dictionary containing the list of messages, "start" and "end" where "end"
        is (start + 50), or -1 if the function has returned the least recent message
        in the channel.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="Channel_id is not a valid channel")

    ## Check for AccessErrors (..continued)
    if not is_user_in_channel(token, channel_id):
        raise AccessError(description="Cannot view channel messages if you are not a member")

    ## Find the number of messages in the channel
    channel_msgs = []
    messages_data = MESSAGES_DATABASE.get()
    for message in messages_data["messages"]:
        if message["channel_id"] == channel_id:
            channel_msgs.append(message)
    num_msgs = len(channel_msgs)

    ## Check for InputErrors (..continued)
    ## If there are 50 messages, and start = 50, then start refers to the 51st
    ## message which does not exist, so raise an error when start >= num_msgs.
    ## Assume an error is not raised when start = 0 (0 messages)
    if start >= num_msgs and start != 0:
        raise InputError(description="start is greater than or equal to number of messages")

    ## Find value for end
    if num_msgs > start + 50:
        end = start + 50
    else:
        end = -1

    ## Reverse the list so that message in index 0 is the most recent
    channel_msgs.reverse()

    ## Create the messages to return
    msg_list = []
    for i in range(start, start + 50):
        ## If num_msgs = 2, then i = 0, 1 will append those messages
        ## So break when i = 2 (hence i >= num_msgs)
        ##
        ## Say num_msgs = 50, then i = 0, ..., 49 will append these
        ## So dont break when i = 49 = num_msgs - 1
        if i >= num_msgs:
            break

        ## Find is_this_user_reacted
        new_reacts = channel_msgs[i]["reacts"]
        user_id = find_u_id(token)
        for react in new_reacts:
            if user_id in react["u_ids"]:
                react["is_this_user_reacted"] = True
            else:
                react["is_this_user_reacted"] = False

        msg_list.append({
            "message_id": channel_msgs[i]["message_id"],
            "u_id": channel_msgs[i]["u_id"],
            "message": channel_msgs[i]["message"],
            "time_created": channel_msgs[i]["time_created"],
            "reacts": new_reacts,
            "is_pinned": channel_msgs[i]["is_pinned"]
        })

    ## Return the messages
    return {
        "messages": msg_list,
        "start": start,
        "end": end
    }


def channel_leave(token, channel_id):
    """
    Remove a given user as a member of a given channel.

    Args:
        token (str): Token of the user leaving a channel.
        channel_id (int): id of the channel that the user is leaving.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a member of the given channel.
        InputError: if channel_id is not a valid channel.
    Returns:
        Empty dictionary.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="Cannot leave a nonexistent channel")

    ## Check for AccessErrors (..continued)
    if not is_user_in_channel(token, channel_id):
        raise AccessError(description="Only members can leave a channel")

    ## Update database
    u_id = find_u_id(token)
    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            ## Remove from all_members
            list_all_members = channel["all_members"]
            for member in list_all_members:
                if member["u_id"] == u_id:
                    list_all_members.remove(member)
            ## Remove from owner members
            list_owner_members = channel["owner_members"]
            for member in list_owner_members:
                if member["u_id"] == u_id:
                    list_owner_members.remove(member)
            break
    CHANNELS_DATABASE.update(channels_data)
    return {}


def channel_join(token, channel_id):
    """
    User joins a channel if they are authorised.

    Args:
        token (str): Token of the user attempting to join a channel.
        channel_id (int): id of the channel that the user is joining.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the channel is private and the user is not a Slackr owner.
        InputError: if channel_id is not a valid channel.
    Returns:
        Empty dictionary.
    """
    ## Check for AcessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="Cannot join a nonexistent channel")

    u_id = find_u_id(token)
    user_data = user_profile(token, u_id)
    first_name = user_data["user"]["name_first"]
    last_name = user_data["user"]["name_last"]
    profile_img_url = user_data["user"]["profile_img_url"]
    user_dict = {
        "u_id": u_id,
        "name_first": first_name,
        "name_last": last_name,
        "profile_img_url": profile_img_url
    }

    ## Add the user to the list of all_members
    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            list_all_members = channel["all_members"]
            list_owner_members = channel["owner_members"]
            ## Check for AccessErrors (..continued)
            if not channel["is_public"] and not is_user_slackr_owner(u_id):
                raise AccessError(description="Non-owners cannot join a private channel")
            ## Slackr owners automatically get owner privileges when joining
            if is_user_slackr_owner(u_id):
                list_owner_members.append(user_dict)
            list_all_members.append(user_dict)
            break
    CHANNELS_DATABASE.update(channels_data)
    return {}


def channel_addowner(token, channel_id, u_id):
    """
    Make a user an owner of a channel.

    Args:
        token (str): Token of the user who is adding an owner.
        channel_id (int): id of the channel that the user is becoming an owner in.
        u_id (int): id of the user being promoted to an owner.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a Slackr owner nor a channel owner.
        InputError: if channel_id is not a valid channel.
        InputError: if the user being promoted is already an owner of the channel.
    Returns:
        Empty dictionary.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="Channel does not exist")

    ## Check for AccessErrors (..continued)
    if not is_user_owner(token, channel_id):
        raise AccessError(description="Only channel & Slackr owners can add owners")

    user_data = user_profile(token, u_id)
    first_name = user_data["user"]["name_first"]
    last_name = user_data["user"]["name_last"]
    profile_img_url = user_data["user"]["profile_img_url"]
    result = {
        "u_id": u_id,
        "name_first": first_name,
        "name_last": last_name,
        "profile_img_url": profile_img_url
    }

    ## Add member to owner_members
    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            list_owner_members = channel["owner_members"]
            ## Check for InputErrors (..continued)
            if any(member["u_id"] == u_id for member in list_owner_members):
                raise InputError(description="User is already an owner of the channel")
            list_owner_members.append(result)
            break
    CHANNELS_DATABASE.update(channels_data)
    return {}


def channel_removeowner(token, channel_id, u_id):
    """
    Remove an owner from a channel, making them a member.

    Args:
        token (str): Token of the user who is removing ownership.
        channel_id (int): id of the channel in which an owner is being demoted.
        u_id (int): id of the user being demoted to a channel member.
    Raises:
        AccessError: if token is invalid.
        AccessError: if the user making the request is not a Slackr owner nor a channel owner.
        InputError: if channel_id is not a valid channel.
        InputError: if the user being demoted is not an owner of the channel.
    Returns:
        Empty dictionary.
    """
    ## Check for AccessErrors
    if not is_token_valid(token):
        raise AccessError(description="Token is not a valid token")

    ## Check for InputErrors
    if not does_channel_exist(channel_id):
        raise InputError(description="Channel does not exist")

    ## Check for AccessErrors (..continued)
    if not is_user_owner(token, channel_id):
        raise AccessError(description="Only owners can remove channel ownership")

    ## Remove member from owner_members
    channels_data = CHANNELS_DATABASE.get()
    list_channels = channels_data["channels"]
    for channel in list_channels:
        if channel["channel_id"] == channel_id:
            list_owner_members = channel["owner_members"]
            ## Check for InputErrors (..continued)
            if not any(member["u_id"] == u_id for member in list_owner_members):
                raise InputError(description="User is not an owner of the channel")
            for member in list_owner_members:
                if member["u_id"] == u_id:
                    list_owner_members.remove(member)
            break
    CHANNELS_DATABASE.update(channels_data)
    return {}
